# Creating the Edit View

## Completed Project

Explore the completed project for [Creating the Edit View](https://developer.apple.com/tutorials/app-dev-training/creating-the-edit-view).